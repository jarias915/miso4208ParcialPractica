package org.secuso.privacyfriendlytodolist.view;

import org.secuso.privacyfriendlytodolist.model.BaseTodo;


public interface TodoCallback {
    void finish(BaseTodo b);
}
